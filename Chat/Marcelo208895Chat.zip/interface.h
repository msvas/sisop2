#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

int chatInterface(int argc, char *argv[], int sock);